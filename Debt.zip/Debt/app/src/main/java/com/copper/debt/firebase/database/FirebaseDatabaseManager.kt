package com.copper.debt.firebase.database

import com.copper.debt.model.Debt
import com.copper.debt.model.User
import javax.inject.Inject

class FirebaseDatabaseManager @Inject constructor() : FirebaseDatabaseInterface {
    override fun listenToDebts(onResult: (Debt) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun addNewDebt(debt: Debt, onResult: (Boolean) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun getMyDebts(userId: String, onResult: (List<Debt>) -> Unit) {
        TODO("Not yet implemented")
    }

    override fun createUser(id: String, name: String, email: String) {
        TODO("Not yet implemented")
    }

    override fun getProfile(id: String, onResult: (User) -> Unit) {
        TODO("Not yet implemented")
    }

}
package com.copper.debt.model

import android.provider.ContactsContract

data class UserResponse(
    val id: String = "",
    val username: String = "",
    val email: String = ""
)

data class User(
    val id: String,
    val username: String,
    val email: String)
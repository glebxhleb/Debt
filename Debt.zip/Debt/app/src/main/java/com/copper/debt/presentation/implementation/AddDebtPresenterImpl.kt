package com.copper.debt.presentation.implementation

import com.copper.debt.common.isValidDebt
import com.copper.debt.firebase.authentication.FirebaseAuthenticationInterface
import com.copper.debt.firebase.database.FirebaseDatabaseInterface
import com.copper.debt.model.Debt
import com.copper.debt.presentation.AddDebtPresenter
import com.copper.debt.ui.addDebt.AddDebtView
import javax.inject.Inject

class AddDebtPresenterImpl @Inject constructor(
    private val authenticationInterface: FirebaseAuthenticationInterface,
    private val databaseInterface: FirebaseDatabaseInterface
) : AddDebtPresenter {
    private lateinit var view: AddDebtView

    private var debtText = ""

    override fun addDebtTapped() {
        if (isValidDebt(debtText)) {
                val debt = Debt(
                    "",
                    authenticationInterface.getUserName(),
                    authenticationInterface.getUserId(),
                    debtText
                )

                databaseInterface.addNewDebt(debt) { onAddDebtResult(it) }
            }
    }

    private fun onAddDebtResult(isSuccessful: Boolean) {
        if( isSuccessful) {
            view.onDebtAdded()
        } else {
            view.showAddDebtError()
        }
    }

    override fun onDebtTextChanged(debtText: String) {
        this.debtText = debtText

        if (!isValidDebt(debtText)) {
            view.showDebtError()
        } else {
            view.removeDebtError()
        }
    }

    override fun setView(view: AddDebtView) {
        this.view = view
    }
}
package com.copper.debt.model

data class DebtResponse(val id: String = "",
                        val creditorName: String = "",
                        val creditorId: String = "",
                        val text: String = "")

fun DebtResponse.isValid() = id.isNotBlank()
        && creditorName.isNotBlank()
        && creditorId.isNotBlank()
        && text.isNotBlank()

data class Debt(val id: String,
                val creditorName: String,
                val creditorId: String,
               val text: String)

//data class DebtResponse(val id: String = "",
//                        val creditorName: String = "",
//                        val creditorId: String = "",
//                        val debtorsNames: List<String> = emptyList(),
//                        val debtorsIds: List<String> = emptyList(),
//                        val loans: List<Float> = emptyList(),
//                        val date: String = "")
//
//fun DebtResponse.isValid() = id.isNotBlank()
//        && creditorName.isNotBlank()
//        && creditorId.isNotBlank()
//        && debtorsNames.isNotEmpty()
//        && debtorsIds.isNotEmpty()
//        && loans.isNotEmpty()
//        && date.isNotBlank()
//
//data class Debt(val id: String,
//                val creditorName: String,
//                val creditorId: String,
//                val debtorsNames: List<String>,
//                val debtorsIds: List<String>,
//                val loans: List<Float>,
//                val date: String)
package com.copper.debt.ui.welcome
interface WelcomeView {

  fun startMainScreen()
}